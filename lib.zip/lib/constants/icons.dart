const _path = 'assets/icons/';

const icFeatured = '$_path/star.png';
const icFeaturedOutlined = '$_path/star_outlined.png';
const icLearning = '$_path/play.png';
const icLearningOutlined = '$_path/play_outlined.png';
const icWishlist = '$_path/heart.png';
const icWishlistOutlined = '$_path/heart_outlined.png';
const icSetting = 'assets/icons/settings.png';
const icSettingOutlined = '$_path/settings_outlined.png';
const icDone = '$_path/done.png';
const icLock = '$_path/lock.png';
const icPlayNext = '$_path/play_next.png';
const icPause = '$_path/pause.png';
