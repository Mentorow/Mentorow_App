import 'package:flutter/material.dart';
import 'package:mentorow/screens/base_screen.dart';
import 'package:mentorow/screens/welcomepage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Education App',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.blue,
     
        textTheme: const TextTheme(
          headline6: TextStyle(
            fontSize: 20,
            color: Colors.white,
            fontWeight: FontWeight.w500,
          ),
          bodyText1: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w500,
          ),
          bodyText2: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          headline5: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 18,
            color: Colors.black,
          ),
        ),
      ),
      home: const  welcomePage(),
    );
  }
}
